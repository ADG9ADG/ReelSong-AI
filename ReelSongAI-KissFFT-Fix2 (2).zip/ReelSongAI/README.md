# ReelSong AI

Android app for identifying music in locally imported Instagram Reel videos and audio files.

## Recognition engine

- Chromaprint generates an audio fingerprint locally on the Android device.
- AcoustID looks up the fingerprint and returns matching MusicBrainz recording metadata.
- The original audio file is not uploaded to AcoustID by this implementation.
- This is intended for personal, non-commercial use. AcoustID's free web service is limited to non-commercial applications and no more than 3 requests per second.

Register an application at https://acoustid.org/new-application to obtain an application API key.

### Configure the key for Android Studio

Create or edit `local.properties` in the project root and add:

```properties
ACOUSTID_APP_KEY=YOUR_ACOUSTID_APPLICATION_KEY
```

Do not commit `local.properties` or publish your personal key. The key is included in the APK at build time and can be extracted from an APK, so this configuration is suitable for personal testing only.

## Build in Android Studio

1. Install Android Studio with Android SDK Platform 35, NDK and CMake 3.22.1, plus JDK 17.
2. Open this project folder.
3. Add your `ACOUSTID_APP_KEY` to `local.properties`.
4. Sync Gradle and build the debug APK.

The CMake build downloads the open-source Chromaprint 1.6.1 source and compiles it for the Android ABIs configured in `app/build.gradle.kts`.

## Build using GitHub Actions

1. Push this project to your GitHub repository.
2. Open **Settings > Secrets and variables > Actions**.
3. Create a repository secret named `ACOUSTID_APP_KEY` with your AcoustID application key.
4. Open **Actions > Build ReelSong AI APK > Run workflow**.
5. Download the `ReelSong-AI-debug-APK` artifact when the workflow completes.

The artifact is a debug-signed APK for personal testing, not a Play Store release.

## Importing a Reel

- Share a downloaded video/audio file to ReelSong AI, or choose it using the file picker.
- Pasting an Instagram URL only validates the link; the app does not scrape Instagram or download protected media.
- The app decodes up to 90 seconds of the selected audio, fingerprints it on-device, then sends only the fingerprint and duration to AcoustID.

## Limitations

- AcoustID is a community fingerprint database, not a universal commercial recognition catalog. Some popular songs, short clips, edits, remixes, sped-up audio, voiceovers and noisy recordings may not match.
- A clip should contain at least 3 seconds of recognizable music; longer, clearer excerpts usually work better.
- Metadata depends on the MusicBrainz data linked to the AcoustID match. Spotify links, label data, BPM, mood and genre analysis are not provided in this version.
- The free AcoustID service is for non-commercial use only and is rate-limited to 3 requests per second. See https://acoustid.org/webservice.
