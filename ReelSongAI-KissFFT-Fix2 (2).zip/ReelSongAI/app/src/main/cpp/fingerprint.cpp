#include <jni.h>
#include <cstdint>
#include <string>
#include "chromaprint.h"

extern "C"
JNIEXPORT jstring JNICALL
Java_com_reelsongai_app_Chromaprint_fingerprint(
    JNIEnv* env, jobject /* thiz */, jbyteArray pcmBytes, jint sampleRate, jint channels) {
    if (pcmBytes == nullptr || sampleRate <= 0 || (channels != 1 && channels != 2)) return nullptr;
    const jsize byteCount = env->GetArrayLength(pcmBytes);
    if (byteCount < 2 * sampleRate * channels * 3) return nullptr;

    jbyte* bytes = env->GetByteArrayElements(pcmBytes, nullptr);
    if (bytes == nullptr) return nullptr;
    auto* samples = reinterpret_cast<const int16_t*>(bytes);
    const int sampleCount = byteCount / static_cast<jsize>(sizeof(int16_t));

    ChromaprintContext* context = chromaprint_new(CHROMAPRINT_ALGORITHM_DEFAULT);
    if (context == nullptr) {
        env->ReleaseByteArrayElements(pcmBytes, bytes, JNI_ABORT);
        return nullptr;
    }

    std::string fingerprint;
    if (chromaprint_start(context, sampleRate, channels) == 1 &&
        chromaprint_feed(context, samples, sampleCount) == 1 &&
        chromaprint_finish(context) == 1) {
        char* encoded = nullptr;
        if (chromaprint_get_fingerprint(context, &encoded) == 1 && encoded != nullptr) {
            fingerprint.assign(encoded);
            chromaprint_dealloc(encoded);
        }
    }
    chromaprint_free(context);
    env->ReleaseByteArrayElements(pcmBytes, bytes, JNI_ABORT);
    if (fingerprint.empty()) return nullptr;
    return env->NewStringUTF(fingerprint.c_str());
}
