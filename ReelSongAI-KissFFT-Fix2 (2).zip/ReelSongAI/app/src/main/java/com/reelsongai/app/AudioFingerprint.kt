package com.reelsongai.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object Chromaprint {
    init { System.loadLibrary("reelsong_fingerprint") }
    external fun fingerprint(pcm: ByteArray, sampleRate: Int, channels: Int): String?
}

object AudioFingerprint {
    private const val MAX_SECONDS = 90
    private val http = OkHttpClient.Builder()
        .callTimeout(25, TimeUnit.SECONDS)
        .connectTimeout(12, TimeUnit.SECONDS)
        .build()

    fun identify(context: Context, uri: Uri): SongResult? {
        val key = BuildConfig.ACOUSTID_APP_KEY
        if (key.isBlank()) {
            error("AcoustID app key missing. Add ACOUSTID_APP_KEY to local.properties.")
        }
        val decoded = decodeToPcm(context, uri)
        val fingerprint = Chromaprint.fingerprint(decoded.pcm, decoded.sampleRate, decoded.channels)
            ?: error("Could not generate an audio fingerprint. Try a longer or clearer clip.")
        val duration = (decoded.pcm.size / 2.0 / decoded.channels / decoded.sampleRate).toInt()
        if (duration < 3) error("The audio clip is too short. Please use at least 3 seconds of audio.")

        val form = FormBody.Builder()
            .add("client", key)
            .add("format", "json")
            .add("duration", duration.toString())
            .add("fingerprint", fingerprint)
            .add("meta", "recordings")
            .add("meta", "releases")
            .add("meta", "releasegroups")
            .build()
        val request = Request.Builder()
            .url("https://api.acoustid.org/v2/lookup")
            .post(form)
            .header("User-Agent", "ReelSongAI/1.1 (personal Android app)")
            .build()

        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                if (response.code == 429) error("AcoustID rate limit reached. Wait a moment and try again.")
                error("AcoustID service error (${response.code}). Please try again.")
            }
            val json = JSONObject(body)
            if (json.optString("status") != "ok") {
                val message = json.optJSONObject("error")?.optString("message").orEmpty()
                error(message.ifBlank { "AcoustID could not process this fingerprint." })
            }
            val results = json.optJSONArray("results") ?: return null
            if (results.length() == 0) return null

            // AcoustID sorts matches by score. Pick the strongest result that has recording metadata.
            for (i in 0 until results.length()) {
                val match = results.optJSONObject(i) ?: continue
                val recordings = match.optJSONArray("recordings") ?: continue
                if (recordings.length() == 0) continue
                val recording = recordings.optJSONObject(0) ?: continue
                val title = recording.optString("title").takeUnless { it == "null" }.orEmpty()
                val artists = recording.optJSONArray("artists")
                val artist = buildList {
                    if (artists != null) for (j in 0 until artists.length()) {
                        artists.optJSONObject(j)?.optString("name")?.takeIf { it.isNotBlank() }?.let(::add)
                    }
                }.distinct().joinToString(", ")

                val releaseGroups = recording.optJSONArray("releasegroups")
                val album = releaseGroups?.optJSONObject(0)?.optString("title").orEmpty()
                val releases = match.optJSONArray("releases")
                val releaseDate = releases?.optJSONObject(0)?.optJSONObject("date")?.let { date ->
                    listOf("year", "month", "day").mapNotNull { k ->
                        if (date.has(k)) date.optInt(k).takeIf { it > 0 }?.toString() else null
                    }.joinToString("-")
                }.orEmpty()

                if (title.isNotBlank()) {
                    return SongResult(
                        title = title,
                        artist = artist,
                        album = album,
                        releaseDate = releaseDate,
                        label = "",
                        spotifyUrl = ""
                    )
                }
            }
            return null
        }
    }

    private data class DecodedAudio(val pcm: ByteArray, val sampleRate: Int, val channels: Int)

    private fun decodeToPcm(context: Context, uri: Uri): DecodedAudio {
        val input = File(context.cacheDir, "reelsong_${System.currentTimeMillis()}.media")
        context.contentResolver.openInputStream(uri)?.use { source ->
            input.outputStream().use { target -> source.copyTo(target) }
        } ?: error("Cannot open the selected media file.")

        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(input.absolutePath)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(i)
                val mime = candidate.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    format = candidate
                    break
                }
            }
            if (track < 0 || format == null) error("No audio track found in this file.")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: error("Unsupported audio format.")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            val output = ByteArrayOutputStream()
            var inputDone = false
            var outputDone = false
            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var sourceChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var outChannels = if (sourceChannels == 2) 2 else 1
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var totalFrames = 0L
            val maxFrames = sampleRate.toLong() * MAX_SECONDS

            while (!outputDone && totalFrames < maxFrames) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex) ?: error("Audio decoder input unavailable.")
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val info = MediaCodec.BufferInfo()
                when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val decodedFormat = decoder.outputFormat
                        sampleRate = decodedFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        sourceChannels = decodedFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        outChannels = if (sourceChannels == 2) 2 else 1
                        if (Build.VERSION.SDK_INT >= 24 && decodedFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            pcmEncoding = decodedFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        }
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val buffer = decoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val chunk = buffer.slice().order(ByteOrder.LITTLE_ENDIAN)
                            val converted = convertPcm(chunk, pcmEncoding, sourceChannels, outChannels)
                            val remainingFrames = maxFrames - totalFrames
                            val bytesPerFrame = 2 * outChannels
                            val allowed = minOf(converted.size, (remainingFrames * bytesPerFrame).toInt())
                            output.write(converted, 0, allowed - (allowed % bytesPerFrame))
                            totalFrames += allowed / bytesPerFrame
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        decoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            val pcm = output.toByteArray()
            if (pcm.size < sampleRate * outChannels * 2 * 3) {
                error("Not enough decoded audio. Please select a clip with at least 3 seconds of sound.")
            }
            return DecodedAudio(pcm, sampleRate, outChannels)
        } finally {
            try { decoder?.stop() } catch (_: Exception) {}
            decoder?.release()
            extractor.release()
            input.delete()
        }
    }

    private fun convertPcm(
        input: ByteBuffer,
        encoding: Int,
        inputChannels: Int,
        outputChannels: Int
    ): ByteArray {
        val bytesPerSample = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
        val frameBytes = bytesPerSample * inputChannels
        val frames = input.remaining() / frameBytes
        val output = ByteBuffer.allocate(frames * outputChannels * 2).order(ByteOrder.LITTLE_ENDIAN)
        repeat(frames) {
            val samples = IntArray(inputChannels) {
                val value = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                    (input.float.coerceIn(-1f, 1f) * 32767f).roundToInt()
                } else {
                    input.short.toInt()
                }
                value
            }
            if (outputChannels == 1) {
                val mixed = (samples.sum().toFloat() / samples.size).roundToInt().coerceIn(-32768, 32767)
                output.putShort(mixed.toShort())
            } else {
                output.putShort(samples[0].coerceIn(-32768, 32767).toShort())
                output.putShort(samples.getOrElse(1) { samples[0] }.coerceIn(-32768, 32767).toShort())
            }
        }
        return output.array()
    }
}
