cmake_minimum_required(VERSION 3.22.1)
project(reelsong_fingerprint LANGUAGES C CXX)

include(FetchContent)
set(BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(FFT_LIB kissfft CACHE STRING "" FORCE)

FetchContent_Declare(
    chromaprint
    URL https://github.com/acoustid/chromaprint/archive/refs/tags/v1.6.1.tar.gz
)
FetchContent_GetProperties(chromaprint)
if(NOT chromaprint_POPULATED)
    FetchContent_Populate(chromaprint)
endif()

set(KISSFFT_ROOT "${chromaprint_SOURCE_DIR}/src/3rdparty/kissfft" CACHE PATH "" FORCE)
add_subdirectory("${chromaprint_SOURCE_DIR}" "${chromaprint_BINARY_DIR}")
set_target_properties(chromaprint_objs PROPERTIES POSITION_INDEPENDENT_CODE TRUE)

add_library(reelsong_fingerprint SHARED fingerprint.cpp)
target_include_directories(reelsong_fingerprint PRIVATE "${chromaprint_SOURCE_DIR}/src")
target_link_libraries(reelsong_fingerprint PRIVATE chromaprint)
