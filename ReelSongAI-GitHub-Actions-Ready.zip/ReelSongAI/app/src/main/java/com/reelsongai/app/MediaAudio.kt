package com.reelsongai.app

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File

object MediaAudio {
    fun extractToM4a(context: Context, uri: Uri): File {
        val input = File(context.cacheDir, "reelsong_input_${System.currentTimeMillis()}")
        context.contentResolver.openInputStream(uri)?.use { source ->
            input.outputStream().use { target -> source.copyTo(target) }
        } ?: error("Cannot open the selected media file.")

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(input.absolutePath)
            var audioTrack = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    audioFormat = format
                    break
                }
            }
            if (audioTrack < 0 || audioFormat == null) error("No audio track found in this file.")
            extractor.selectTrack(audioTrack)

            val output = File(context.cacheDir, "reelsong_audio_${System.currentTimeMillis()}.m4a")
            val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val outTrack = muxer.addTrack(audioFormat)
                muxer.start()
                val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
                val info = android.media.MediaCodec.BufferInfo()
                while (true) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outTrack, buffer, info)
                    extractor.advance()
                }
                muxer.stop()
            } finally { muxer.release() }
            return output
        } finally {
            extractor.release()
            input.delete()
        }
    }
}
