package com.reelsongai.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private val Ink = Color(0xFF10111A)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReelSongApp(initialUri = sharedUri(intent), initialUrl = sharedText(intent)) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setContent { ReelSongApp(initialUri = sharedUri(intent), initialUrl = sharedText(intent)) }
    }

    private fun sharedUri(intent: Intent?): Uri? {
        if (intent?.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            return intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        return null
    }

    private fun sharedText(intent: Intent?): String {
        return if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReelSongApp(initialUri: Uri?, initialUrl: String = "") {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf(initialUri) }
    var reelUrl by remember { mutableStateOf(initialUrl) }
    var status by remember { mutableStateOf("Import a Reel video or audio file to identify its music.") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SongResult?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            result = null
            status = "File selected. Tap Identify song."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Cyan, background = Ink,
            surface = Color(0xFF1B1C29), onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.MusicNote, null, tint = Color.White) }
                    Column {
                        Text("ReelSong AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Discover the sound behind the Reel", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Import your Reel", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("Best results: share or select the actual video. A pasted Instagram URL may not expose its audio.", color = Color.LightGray)
                        OutlinedTextField(
                            value = reelUrl, onValueChange = { reelUrl = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Instagram Reel link (optional)") },
                            leadingIcon = { Icon(Icons.Default.Link, null) },
                            placeholder = { Text("https://www.instagram.com/reel/...") }
                        )
                        Button(
                            onClick = {
                                val valid = reelUrl.contains("instagram.com/") && (reelUrl.contains("/reel/") || reelUrl.contains("/reels/"))
                                status = if (valid) "Link saved. Instagram links are not directly downloadable here. Please import the Reel video for reliable recognition."
                                         else "Enter a valid Instagram Reel URL."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Check Reel link") }

                        OutlinedButton(
                            onClick = { picker.launch(arrayOf("video/*", "audio/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.UploadFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Choose downloaded Reel / audio")
                        }
                        Text(
                            selectedUri?.lastPathSegment?.take(70) ?: "No media file selected",
                            color = if (selectedUri != null) Cyan else Color.Gray,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Button(
                    enabled = selectedUri != null && !busy,
                    onClick = {
                        val uri = selectedUri ?: return@Button
                        busy = true
                        result = null
                        status = "Extracting audio and identifying the song…"
                        scope.launch {
                            try {
                                val song = withContext(Dispatchers.IO) {
                                    val file = MediaAudio.extractToM4a(context, uri)
                                    AudDClient.identify(file)
                                }
                                result = song
                                status = if (song != null) "Song identified." else "No matching song was found."
                            } catch (e: Exception) {
                                status = e.message ?: "Something went wrong. Please try another clip."
                            } finally { busy = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.AudioFile, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "Analysing…" else "Identify background song")
                }

                Text(status, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)

                result?.let { song ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("IDENTIFICATION RESULT", color = Cyan, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(song.artist.ifBlank { "Artist unavailable" }, color = Color.LightGray)
                            Divider(color = Color.DarkGray)
                            song.album.takeIf { it.isNotBlank() }?.let { DetailRow("Album", it) }
                            song.releaseDate.takeIf { it.isNotBlank() }?.let { DetailRow("Release date", it) }
                            song.label.takeIf { it.isNotBlank() }?.let { DetailRow("Label", it) }
                            song.spotifyUrl.takeIf { it.startsWith("https://") }?.let { url ->
                                OutlinedButton(onClick = {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                }, modifier = Modifier.fillMaxWidth()) { Text("Open on Spotify") }
                            }
                        }
                    }
                }

                Text(
                    "Privacy: the selected audio is uploaded to AudD only after you tap Identify. Do not submit private media unless you agree to that processing.",
                    color = Color.Gray, style = MaterialTheme.typography.labelSmall
                )
                Text("ReelSong AI • Version 1.0", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.Gray)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

data class SongResult(
    val title: String, val artist: String, val album: String,
    val releaseDate: String, val label: String, val spotifyUrl: String
)
