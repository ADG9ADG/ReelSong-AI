package com.reelsongai.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Ink = Color(0xFF10111A)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReelSongApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReelSongApp() {
    val context = LocalContext.current
    val activity = context as Activity
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Play an Instagram Reel, then tap Listen to Reel.") }
    var result by remember { mutableStateOf<SongResult?>(null) }

    val projectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { response ->
        if (response.resultCode == Activity.RESULT_OK && response.data != null) {
            busy = true
            result = null
            status = "Listening to internal audio for 20 seconds. Switch to Instagram and play the Reel now."
            val serviceIntent = Intent(context, PlaybackCaptureService::class.java).apply {
                action = PlaybackCaptureService.ACTION_START
                putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, response.resultCode)
                putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, response.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
            else context.startService(serviceIntent)
        } else {
            status = "Audio capture permission was cancelled. Tap Listen to Reel and allow sharing audio."
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            status = "Android will now ask permission to capture this session's audio."
            projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
        } else {
            status = "Microphone/audio permission is required by Android to start playback capture."
        }
    }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    PlaybackCaptureService.ACTION_CAPTURE_DONE -> {
                        val path = intent.getStringExtra(PlaybackCaptureService.EXTRA_FILE_PATH)
                        if (path.isNullOrBlank()) {
                            busy = false
                            status = "Audio capture ended without an audio file. Try again."
                        } else {
                            status = "Audio captured. Identifying the song…"
                            scope.launch {
                                try {
                                    val song = withContext(Dispatchers.IO) {
                                        AudioFingerprint.identify(context, Uri.fromFile(File(path)))
                                    }
                                    result = song
                                    status = if (song != null) "Song identified."
                                        else "No matching recording found. Try a clearer or longer section."
                                } catch (e: Exception) {
                                    status = e.message ?: "Could not identify this audio."
                                } finally {
                                    busy = false
                                }
                            }
                        }
                    }
                    PlaybackCaptureService.ACTION_CAPTURE_ERROR -> {
                        busy = false
                        status = intent.getStringExtra(PlaybackCaptureService.EXTRA_ERROR)
                            ?: "Could not capture audio. Instagram may not allow playback capture."
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(PlaybackCaptureService.ACTION_CAPTURE_DONE)
            addAction(PlaybackCaptureService.ACTION_CAPTURE_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Cyan, background = Ink,
            surface = Color(0xFF1B1C29), onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(54.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Column {
                        Text("ReelSong AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Identify music playing in a Reel", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Listen to Instagram Reel", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            "1. Open Instagram and play the Reel.\\n2. Return to ReelSong AI.\\n3. Tap Listen to Reel, approve Android's capture prompt, then switch back to Instagram and play the Reel for 20 seconds.",
                            color = Color.LightGray
                        )
                        Button(
                            enabled = !busy,
                            onClick = {
                                if (Build.VERSION.SDK_INT < 29) {
                                    status = "Internal audio capture requires Android 10 or newer."
                                } else {
                                    audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            else Icon(Icons.Default.GraphicEq, null)
                            Spacer(Modifier.width(10.dp))
                            Text(if (busy) "Listening / analysing…" else "Listen to Reel")
                        }
                        Text(status, color = if (busy) Cyan else Color.LightGray, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                result?.let { song ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("IDENTIFIED SONG", color = Cyan, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(song.artist.ifBlank { "Artist unavailable" }, color = Color.LightGray)
                            if (song.album.isNotBlank()) Text("Album: ${song.album}", color = Color.LightGray)
                            if (song.releaseDate.isNotBlank()) Text("Release: ${song.releaseDate}", color = Color.LightGray)
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    "No Reel video is downloaded. Android's system audio-capture permission is required each session. Some apps may block capture. The audio fingerprint and duration are sent to AcoustID for matching.",
                    color = Color.Gray, style = MaterialTheme.typography.labelSmall
                )
                Text("ReelSong AI • Internal Audio Edition", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
