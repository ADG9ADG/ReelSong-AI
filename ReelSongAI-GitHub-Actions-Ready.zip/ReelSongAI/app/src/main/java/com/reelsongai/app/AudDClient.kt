package com.reelsongai.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object AudDClient {
    private val client = OkHttpClient.Builder()
        .callTimeout(90, TimeUnit.SECONDS)
        .build()

    fun identify(audioFile: File): SongResult? {
        if (BuildConfig.AUDD_API_TOKEN.isBlank()) {
            error("AudD API key missing. Add AUDD_API_TOKEN to local.properties and sync Gradle.")
        }
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("api_token", BuildConfig.AUDD_API_TOKEN)
            .addFormDataPart("return", "spotify")
            .addFormDataPart("file", audioFile.name, audioFile.asRequestBody("audio/mp4".toMediaType()))
            .build()
        val request = Request.Builder().url("https://api.audd.io/").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Recognition service error (${response.code}). Please try again.")
            val json = JSONObject(raw)
            if (json.optString("status") != "success") {
                error(json.optString("error", "Recognition service could not identify this audio."))
            }
            val data = json.optJSONObject("result") ?: return null
            val spotify = data.optJSONObject("spotify")
            return SongResult(
                title = data.optString("title"),
                artist = data.optString("artist"),
                album = data.optString("album"),
                releaseDate = data.optString("release_date"),
                label = data.optString("label"),
                spotifyUrl = spotify?.optJSONObject("external_urls")?.optString("spotify").orEmpty()
            )
        }
    }
}
