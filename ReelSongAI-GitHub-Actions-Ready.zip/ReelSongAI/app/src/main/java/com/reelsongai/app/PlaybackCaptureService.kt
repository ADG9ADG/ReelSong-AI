package com.reelsongai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class PlaybackCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.reelsongai.app.CAPTURE_START"
        const val ACTION_CAPTURE_DONE = "com.reelsongai.app.CAPTURE_DONE"
        const val ACTION_CAPTURE_ERROR = "com.reelsongai.app.CAPTURE_ERROR"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_FILE_PATH = "captured_file_path"
        const val EXTRA_ERROR = "capture_error"
        private const val CHANNEL_ID = "reelsong_capture"
        private const val NOTIFICATION_ID = 401
        private const val SAMPLE_RATE = 44100
        private const val CAPTURE_SECONDS = 20
    }

    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("ReelSong AI is listening")
            .setContentText("Capturing internal audio for song identification")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        Thread {
            try {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                } ?: error("Android did not provide audio-capture permission data.")

                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(resultCode, data)
                    ?: error("Android could not start internal audio capture.")
                val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()
                val minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBuffer <= 0) error("This device does not support the requested audio capture format.")
                recorder = AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(maxOf(minBuffer * 2, SAMPLE_RATE))
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
                if (recorder?.state != AudioRecord.STATE_INITIALIZED) error("Could not initialise internal audio capture.")
                val pcm = ByteArrayOutputStream()
                val buffer = ByteArray(maxOf(minBuffer, 4096))
                recorder!!.startRecording()
                val endAt = SystemClock.elapsedRealtime() + CAPTURE_SECONDS * 1000L
                while (SystemClock.elapsedRealtime() < endAt) {
                    val count = recorder!!.read(buffer, 0, buffer.size)
                    if (count > 0) pcm.write(buffer, 0, count)
                    else if (count < 0) error("Audio capture stopped unexpectedly ($count).")
                }
                recorder?.stop()
                val raw = pcm.toByteArray()
                if (raw.size < SAMPLE_RATE * 2 * 3) {
                    error("No usable internal audio was captured. Instagram may block playback capture, or the Reel was not playing.")
                }
                val file = File(cacheDir, "reelsong_capture_${System.currentTimeMillis()}.wav")
                writeWav(file, raw, SAMPLE_RATE, 1)
                sendBroadcast(Intent(ACTION_CAPTURE_DONE).setPackage(packageName).putExtra(EXTRA_FILE_PATH, file.absolutePath))
            } catch (e: Exception) {
                sendBroadcast(Intent(ACTION_CAPTURE_ERROR).setPackage(packageName)
                    .putExtra(EXTRA_ERROR, e.message ?: "Internal audio capture failed."))
            } finally {
                runCatching { recorder?.stop() }
                recorder?.release()
                recorder = null
                projection?.stop()
                projection = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun writeWav(file: File, pcm: ByteArray, sampleRate: Int, channels: Int) {
        val byteRate = sampleRate * channels * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + pcm.size)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1)
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort((channels * 2).toShort())
        header.putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcm.size)
        FileOutputStream(file).use { it.write(header.array()); it.write(pcm) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "ReelSong audio capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
