package com.reelsongai.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF10111A)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReelSongApp(initialUri = sharedUri(intent), initialUrl = sharedText(intent)) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setContent { ReelSongApp(initialUri = sharedUri(intent), initialUrl = sharedText(intent)) }
    }

    private fun sharedUri(intent: Intent?): Uri? {
        if (intent?.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            return intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        return null
    }

    private fun sharedText(intent: Intent?): String {
        return if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReelSongApp(initialUri: Uri?, initialUrl: String = "") {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf(initialUri) }
    var reelUrl by remember { mutableStateOf(initialUrl) }
    var status by remember { mutableStateOf("Import a Reel video or audio file to identify its music.") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SongResult?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            result = null
            status = "File selected. Tap Identify song."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Cyan, background = Ink,
            surface = Color(0xFF1B1C29), onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.MusicNote, null, tint = Color.White) }
                    Column {
                        Text("ReelSong AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Free personal music recognition", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Import your Reel", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("Paste a public Reel link to try automatic fetching, or share/select the video. Instagram may block links that require login or are private.", color = Color.LightGray)
                        OutlinedTextField(
                            value = reelUrl, onValueChange = { reelUrl = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Instagram Reel link (optional)") },
                            leadingIcon = { Icon(Icons.Default.Link, null) },
                            placeholder = { Text("https://www.instagram.com/reel/...") }
                        )
                        Button(
                            enabled = !busy,
                            onClick = {
                                val valid = reelUrl.contains("instagram.com/") &&
                                    (reelUrl.contains("/reel/") || reelUrl.contains("/reels/"))
                                if (!valid) {
                                    status = "Enter a valid public Instagram Reel URL."
                                } else {
                                    busy = true
                                    result = null
                                    selectedUri = null
                                    status = "Fetching public Reel video from Instagram…"
                                    scope.launch {
                                        try {
                                            val fetched = withContext(Dispatchers.IO) {
                                                val videoUri = downloadPublicInstagramReel(context, reelUrl)
                                                val identifiedSong = AudioFingerprint.identify(context, videoUri)
                                                videoUri to identifiedSong
                                            }
                                            selectedUri = fetched.first
                                            val song = fetched.second
                                            result = song
                                            status = if (song != null) "Reel fetched. Song identified."
                                                else "Reel fetched, but no matching song was found."
                                        } catch (e: Exception) {
                                            status = e.message ?: "Could not fetch this Reel. Try sharing the actual video to ReelSong AI."
                                        } finally {
                                            busy = false
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            else Icon(Icons.Default.Link, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (busy) "Fetching & analysing…" else "Fetch Reel & identify song")
                        }

                        OutlinedButton(
                            onClick = { picker.launch(arrayOf("video/*", "audio/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.UploadFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Choose downloaded Reel / audio")
                        }
                        Text(
                            selectedUri?.lastPathSegment?.take(70) ?: "No media file selected",
                            color = if (selectedUri != null) Cyan else Color.Gray,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Button(
                    enabled = selectedUri != null && !busy,
                    onClick = {
                        val uri = selectedUri ?: return@Button
                        busy = true
                        result = null
                        status = "Extracting audio and identifying the song…"
                        scope.launch {
                            try {
                                val song = withContext(Dispatchers.IO) {
                                    AudioFingerprint.identify(context, uri)
                                }
                                result = song
                                status = if (song != null) "Song identified." else "No matching song was found."
                            } catch (e: Exception) {
                                status = e.message ?: "Something went wrong. Please try another clip."
                            } finally { busy = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.AudioFile, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "Analysing…" else "Identify background song")
                }

                Text(status, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)

                result?.let { song ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202133)), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("IDENTIFICATION RESULT", color = Cyan, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(song.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text(song.artist.ifBlank { "Artist unavailable" }, color = Color.LightGray)
                            Divider(color = Color.DarkGray)
                            song.album.takeIf { it.isNotBlank() }?.let { DetailRow("Album", it) }
                            song.releaseDate.takeIf { it.isNotBlank() }?.let { DetailRow("Release date", it) }

                        }
                    }
                }

                Text(
                    "Privacy: audio is fingerprinted on this device. Only the fingerprint and clip duration are sent to AcoustID for matching.",
                    color = Color.Gray, style = MaterialTheme.typography.labelSmall
                )
                Text("ReelSong AI • Version 1.0", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}


/**
 * Best-effort fetch for PUBLIC Instagram Reels.
 * Instagram does not provide a stable public download API for arbitrary Reels,
 * so this reads public page metadata and may fail for private/login-gated content.
 */
private fun downloadPublicInstagramReel(context: Context, rawUrl: String): Uri {
    val parsed = Uri.parse(rawUrl.trim())
    val host = parsed.host?.lowercase().orEmpty()
    if (parsed.scheme !in listOf("http", "https") ||
        !(host == "instagram.com" || host.endsWith(".instagram.com")) ||
        !(parsed.path.orEmpty().contains("/reel/") || parsed.path.orEmpty().contains("/reels/"))) {
        error("Please paste a valid Instagram Reel link.")
    }

    val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    val pageRequest = Request.Builder()
        .url(rawUrl.trim())
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
        .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        .header("Accept-Language", "en-US,en;q=0.8")
        .build()

    val html = client.newCall(pageRequest).execute().use { response ->
        if (!response.isSuccessful) {
            error("Instagram blocked this Reel link (${response.code}). Try sharing the video directly to ReelSong AI.")
        }
        response.body?.string().orEmpty()
    }

    fun cleanUrl(value: String): String {
        return value
            .replace("\\\\u0026", "&")
            .replace("\\u0026", "&")
            .replace("\\/", "/")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("\\\\/", "/")
            .trim()
    }

    val candidates = mutableListOf<String>()
    val patterns = listOf(
        Regex("""<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
        Regex("""<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:video(?::secure_url)?["']""", RegexOption.IGNORE_CASE),
        Regex(""""video_url"\s*:\s*"((?:\\.|[^"])*)""""),
        Regex(""""playable_url"\s*:\s*"((?:\\.|[^"])*)"""")
    )
    for (pattern in patterns) {
        pattern.findAll(html).forEach { match ->
            match.groupValues.getOrNull(1)?.let { candidates += cleanUrl(it) }
        }
    }

    val videoUrl = candidates.firstOrNull { candidate ->
        val u = runCatching { Uri.parse(candidate) }.getOrNull()
        val h = u?.host?.lowercase().orEmpty()
        u?.scheme == "https" &&
            (h.endsWith("fbcdn.net") || h.endsWith("cdninstagram.com") || h == "instagram.com" || h.endsWith(".instagram.com"))
    } ?: error("Instagram did not expose a downloadable video for this link. It may be private, login-only, or blocked. Share the actual Reel video to ReelSong AI instead.")

    val videoRequest = Request.Builder()
        .url(videoUrl)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
        .header("Referer", "https://www.instagram.com/")
        .build()

    val target = File(context.cacheDir, "reelsong_reel_${System.currentTimeMillis()}.mp4")
    client.newCall(videoRequest).execute().use { response ->
        if (!response.isSuccessful) error("Instagram's video server refused the download (${response.code}).")
        val body = response.body ?: error("Instagram returned an empty video.")
        val contentType = body.contentType()?.toString().orEmpty()
        if (!contentType.contains("video", ignoreCase = true) && !contentType.contains("octet-stream", ignoreCase = true)) {
            error("Instagram did not return a video file for this Reel.")
        }
        val maxBytes = 100L * 1024L * 1024L
        if ((body.contentLength() > maxBytes)) error("This Reel is larger than the 100 MB import limit.")
        body.byteStream().use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > maxBytes) error("This Reel is larger than the 100 MB import limit.")
                    output.write(buffer, 0, count)
                }
            }
        }
    }
    return Uri.fromFile(target)
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.Gray)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

data class SongResult(
    val title: String, val artist: String, val album: String,
    val releaseDate: String, val label: String, val spotifyUrl: String
)
