cmake_minimum_required(VERSION 3.22.1)
project(reelsong_fingerprint LANGUAGES C CXX)

include(FetchContent)

# Chromaprint needs the KissFFT source files when FFT_LIB=kissfft.
# Fetch KissFFT explicitly because the Chromaprint source archive does not
# include its git submodule contents.
FetchContent_Declare(
    kissfft
    URL https://github.com/mborgerding/kissfft/archive/refs/tags/131.1.0.tar.gz
)
FetchContent_GetProperties(kissfft)
if(NOT kissfft_POPULATED)
    FetchContent_Populate(kissfft)
endif()
set(KISSFFT_ROOT "${kissfft_SOURCE_DIR}" CACHE PATH "KissFFT source directory" FORCE)

set(BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(FFT_LIB kissfft CACHE STRING "" FORCE)

FetchContent_Declare(
    chromaprint
    URL https://github.com/acoustid/chromaprint/archive/refs/tags/v1.6.1.tar.gz
)
FetchContent_GetProperties(chromaprint)
if(NOT chromaprint_POPULATED)
    FetchContent_Populate(chromaprint)
endif()

add_subdirectory("${chromaprint_SOURCE_DIR}" "${chromaprint_BINARY_DIR}")
set_target_properties(chromaprint_objs PROPERTIES POSITION_INDEPENDENT_CODE TRUE)

add_library(reelsong_fingerprint SHARED fingerprint.cpp)
target_include_directories(reelsong_fingerprint PRIVATE "${chromaprint_SOURCE_DIR}/src")
target_link_libraries(reelsong_fingerprint PRIVATE chromaprint)
